# MemGuardOS 安全与精准遗忘设计

## 1. 安全目标

MemGuardOS 在三个阶段保护智能体记忆：

1. **入库前**：识别并阻断敏感数据。
2. **检索时**：不返回已删除或高风险记忆。
3. **遗忘后**：确保被遗忘明文不能从元数据、索引或段文件中恢复。

设计上同时使用应用层规则和 OS 上下文信号。

## 2. 威胁模型

| 威胁 | 示例 | 缓解措施 |
|---|---|---|
| 凭据被记忆 | API key、token、private key 进入记忆 | 高风险检测直接阻断 |
| PII 泄漏 | 邮箱、手机号、身份证进入记忆 | 脱敏后存储 |
| 敏感文件被智能体读取 | `.ssh/id_rsa`、`.env`、`/etc/shadow` | OS 路径信号提高风险等级 |
| 遗忘后仍可检索 | 内容残留在索引、缓存、段文件 | tombstone、元数据清除、图谱清除、compact、探针验证 |
| 审计被篡改 | 操作日志被修改 | 哈希链验证 |
| 并发审计分叉 | 多个 Agent/daemon 同时写审计时读到相同前序哈希 | SQLite 写锁事务保护前序哈希读取和事件写入 |
| 过度遗忘 | 宽泛请求误删无关知识 | dry-run 候选和 keep-success 指标 |

## 3. 敏感检测

实现文件：

- `memguard/sensitivity/detector.py`
- `memguard/sensitivity/custom_patterns.py`

检测来源：

1. 内置模式：邮箱、手机号、身份证、中文姓名、中文地址、银行卡号、API key、AWS Access Key ID、token/password/secret 赋值、private key。
2. 自定义模式：通过 `memctl patterns add` 添加，或通过 `memctl patterns suggest/add-natural` 从受限自然语言指令生成。
3. OS 来源信号：`.env`、`.ssh`、`authorized_keys`、`id_rsa`、`.aws/credentials`、`.kube/config`、service account key、`/etc/shadow`、`/etc/ssh`。

策略：

| 等级 | 动作 |
|---|---|
| high | 阻断存储，写入审计 |
| medium | 脱敏后存储 |
| low | 脱敏后存储 |
| none | 正常存储 |

自然语言自定义规则采用保守解析器，只支持可解释格式，例如“以 MG- 开头后接 6 位数字”或“形如 OPS-2026-0001”。生成结果仍需通过正则编译、空匹配和过宽匹配校验，避免把自然语言生成能力变成不可控的误杀来源。

## 4. OS 级敏感访问

实现文件：

- `memguard/os_guard/events.py`
- `memguard/os_guard/auditd.py`
- `scripts/install_auditd_rules.sh`
- `scripts/auditd_to_memguard.sh`

流程：

```text
auditd/fanotify/eBPF 风格事件
  -> ingest-os-event / ingest-auditd
  -> 解析 path/process/action
  -> 路径进入敏感检测器
  -> 高风险 OS 来源被阻断
  -> 审计事件记录
```

便携 smoke test：

```bash
python -m memguard.cli.memctl ingest-os-event --json '{"event_type":"fanotify_open","path":"/home/u/.ssh/id_rsa","process":"cat","action":"read"}'
```

openKylin auditd 验证：

```bash
python -m memguard.cli.memctl auditd-rules --format auditctl
sudo bash scripts/install_auditd_rules.sh "$(pwd)"
sudo ausearch -k memguard_sensitive -i
```

## 5. 精准遗忘

实现文件：

- `memguard/forgetting/planner.py`
- `MemGuardService.forget()`
- `MemGuardService.compact()`
- `MemGuardService.verify_forget_probe()`

流程：

```text
请求："忘掉 temporary project codename"
  -> 关键词/实体候选选择
  -> dry-run 预览
  -> 确认后 tombstone
  -> SQLite 内容清除
  -> FTS 删除
  -> 图谱边删除
  -> compact 段文件
  -> 明文探针验证
```

关键行为：

- dry-run 不删除任何内容。
- 确认遗忘会清除元数据明文和搜索索引。
- `compact()` 从追加式段文件历史中移除旧明文。
- `verify-forget --probe` 检查明文探针是否仍存在于段文件。

## 6. 审计哈希链

实现文件：

- `SQLiteMetaStore.add_audit()`
- `SQLiteMetaStore.verify_audit_chain()`

每条审计事件包含：

```text
prev_hash
event_hash = SHA256(prev_hash | event_type | memory_id | detail | created_at)
```

并发保证：

- `add_audit()` 使用 `BEGIN IMMEDIATE` 把前序哈希读取和新审计事件插入放入同一写锁临界区。
- SQLite 连接设置 `busy_timeout`，降低 daemon、CLI 和 API 并发写入时的锁冲突。
- 并发审计回归覆盖 6 线程写入后哈希链校验，最终 openKylin 汇总证据位于 `docs/evidence/openkylin/`。

验证命令：

```bash
python -m memguard.cli.memctl verify-audit
```

期望结果：

```json
{
  "ok": true,
  "checked": 12,
  "head_hash": "..."
}
```

## 7. 本地控制台与 API 边界

Web 控制台属于本地运维界面，不是公网管理后台。当前实现对所有 `/api/*` 路径统一执行 Bearer Token 校验，未授权请求不能读取诊断、导出诊断包、写入记忆或执行遗忘。浏览器端 token 只保存在 `sessionStorage`，避免长期持久化到 `localStorage`。控制台响应同时带有 `Cache-Control: no-store`、`X-Frame-Options: DENY`、`X-Content-Type-Options: nosniff`、`Referrer-Policy: no-referrer`、`Cross-Origin-Opener-Policy: same-origin`、`Permissions-Policy` 和 HTML CSP，用于降低本地页面被嵌入、缓存或滥用浏览器权限的风险。

Unix socket API 默认面向本机可信 Agent。多人环境中建议使用 `--socket-mode 660` 配合专用用户组，并通过 `--auth-token-file` 启用本地 bearer token。MemGuardOS 当前不宣称具备公网 SaaS 的完整账号体系、SSO 或 RBAC；如果未来需要对外暴露，应在现有本地鉴权之外增加 TLS、限流、细粒度权限、访问审计和密钥轮换策略。

## 8. 安全评测

当前评测包括：

- 敏感阻断 F1；
- 脱敏 F1；
- 敏感标签 F1；
- 遗忘候选精确率；
- 遗忘候选召回率；
- 应保留记忆成功率；
- 审计哈希链测试；
- compact 不可逆清除测试；
- OS 敏感路径测试。

为了降低误报，中文姓名和地址检测采用上下文触发策略，例如“姓名是张三”“收货地址是北京市...”会脱敏；普通中文短语不会被当作姓名处理。

运行：

```bash
python -m pytest -q
python -m memguard.eval.run_eval --latency-size 1000 --latency-queries 120 --output output/eval_result.json --markdown output/eval_report.md
```

## 9. 可选扩展接口

当前安全链路已经覆盖写入前阻断、脱敏、OS 事件接入、auditd、BPF LSM 安全测试文件强制拒绝、BPF 静态 denylist 策略生成、精准遗忘和审计哈希链。系统保留以下扩展接口，便于在目标环境需要时增强：

1. NER/LLM 校验器可通过 `MEMGUARD_EXTRACTOR_COMMAND` 或显式 provider 接入，不影响默认离线评测路径；增强器必须返回合法 JSON schema，失败会回退。
2. fanotify 或新的 eBPF 事件生产者可继续输出统一 `ingest-os-event` 格式。
3. 审计导出可以在现有哈希链基础上增加签名或归档。
4. 阻断、脱敏、隔离、人工确认策略可在现有敏感等级上扩展。
5. BPF LSM 策略可以从 JSON 生成静态 header，在隔离环境审查后编译加载；默认仍只拦截安全测试文件，避免影响登录链路。
