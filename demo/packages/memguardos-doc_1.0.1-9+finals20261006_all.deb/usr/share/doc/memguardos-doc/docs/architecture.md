# MemGuardOS 总体设计

## 1. 项目定位

MemGuardOS 是面向 Linux/openKylin OS Agent 的记忆基础设施，解决三个核心问题：

1. 智能体如何从用户与 Agent 的消息、反馈、工具调用、工具结果及补充 OS 数据中提取有价值记忆？
2. 这些记忆如何在 Linux 机制下被检索、版本化、审计和资源约束？
3. 敏感或过期记忆如何以可审计、可验证、不可逆的方式精准遗忘？

MemGuardOS 不是通用 RAG demo，而是把智能体记忆当作 OS 管理资源，核心能力包括：

- 多源记忆接入；
- 可解释混合语义抽取；
- working/session/long_term 记忆层级；
- 追加式版本化存储；
- 图谱化知识记忆；
- 带 OS 上下文的敏感检测；
- 自然语言精准遗忘；
- 审计哈希链验证；
- openKylin/namespace/systemd/auditd/cgroup/BPF LSM/UKUI/Web 控制台验证路径。
- OpenHands 真实 Agent 适配、跨会话习惯复用和交互范围精准遗忘。

## 2. 总体架构

```mermaid
flowchart LR
    A["用户-Agent 消息 / 反馈 / 工具事件 / 补充 OS 数据"] --> B["统一事件接入层"]
    B --> C["敏感检测"]
    C -->|高风险| D["阻断并审计"]
    C -->|安全或可脱敏| E["记忆提取"]
    E --> F["记忆卡片"]
    F --> S["namespace 隔离存储根"]
    S --> G["mmap 追加式段文件"]
    S --> H["SQLite 元数据 + FTS"]
    F --> I["图谱索引"]
    H --> J["混合检索"]
    I --> J
    J --> K["规划 / 工具选择 / 结果生成上下文"]
    K --> T["OpenHands Hook 注入"]
    T --> U["真实 Agent 执行与事件回收"]
    U --> B
    L["自然语言遗忘请求"] --> M["遗忘规划器"]
    M --> N["候选预览"]
    N --> O["墓碑删除 + 元数据清除 + 图谱清除"]
    O --> P["compact + 泄漏验证"]
    D --> Q["SQLite 审计哈希链"]
    O --> Q
    Q --> R["journald 桥接"]
```

## 3. 核心组件

| 组件 | 职责 | 当前证据 |
|---|---|---|
| CLI `memctl` | 用户与演示入口 | `ingest/search/forget/versions/rollback/doctor/...` |
| Web 控制台 | 本地评审和演示入口 | `memctl web`、`memguard/web/dashboard.py` |
| 记忆卡片 | 统一记忆 schema | `memguard/models.py` |
| 混合抽取器 | 偏好/知识/安全策略抽取和可解释信号 | `memguard/extraction/semantic.py` |
| 敏感检测器 | PII/凭据/自定义模式/OS 路径检测 | `memguard/sensitivity` |
| 追加式存储 | 版本段文件、mmap 读、compact 清除 | `memguard/store/mmap_store.py` |
| SQLite 元数据 | 元数据、FTS、审计、图谱表 | `memguard/store/sqlite_meta.py` |
| 混合检索器 | 词法 + 轻量向量式 + 图谱扩展 | `memguard/retrieval/hybrid.py` |
| 图谱记忆 | 实体/关系抽取和关联检索 | `memguard/extraction/entity.py` |
| 遗忘规划器 | 自然语言候选选择 | `memguard/forgetting/planner.py` |
| OS Guard | namespace、cgroup、journald、auditd、OS 事件 | `memguard/config.py`、`memguard/os_guard` |
| 评测模块 | 指标、延迟负载、报告 | `memguard/eval/run_eval.py` |
| Agent 适配层 | OpenHands 事件规范化、上下文注入、习惯聚合与真实 runner | `memguard/integrations/` |
| Agent bridge | systemd 受限队列任务执行 | `scripts/memguard_agent_bridge.py`、`memguard-agent@.service` |

## 4. 记忆生命周期

1. **接入**：OpenHands 用户消息、Agent 消息、反馈、工具调用和工具结果自动进入统一事件链；文本、文件、配置、shell 与 OS 事件作为补充来源。
2. **抽取**：内容被分为偏好、知识或敏感策略，并记录抽取方法、信号和置信度。
3. **敏感检测**：检查敏感模式和 OS 来源路径。
4. **存储**：安全记忆写入当前 namespace 下的追加式段文件和 SQLite 元数据。
5. **结构化**：抽取实体和关系，写入图谱表。
6. **检索**：授权范围内的 FTS、可选独立语义候选与图谱扩展，经 RRF 融合并按阶段构建上下文。
7. **更新/回滚**：更新和回滚都追加新版本，不覆盖历史。
8. **遗忘**：写入 tombstone、清理索引、compact、验证明文无泄漏。
9. **审计**：关键事件进入哈希链审计日志，并可镜像到 journald。
10. **跨会话复用**：新会话分别在任务规划、工具选择和结果生成阶段读取相关偏好与知识。

对外的生命周期视图将一条记忆组织为四部分：记忆原子描述当前内容、类型、范围和版本；情节视图按 Agent、会话、项目与任务归集形成过程；支持证据标明来源事件及原文跨度；操作记录连接写入、更新、使用与遗忘的审计信息。四部分来自现有权威记录和证据关系，统一用于 CLI、API 与 Web 详情展示。查看时可通过 `memctl lifecycle <记忆编号>` 追溯具体记录，通过 `memctl lifecycle --overview` 查看当前记忆空间的覆盖情况。

SQLite 中已提交的版本决定当前可见状态。段文件中提前追加但尚未提交的版本不会进入生命周期历史，历史沿父版本链展开并去重。遗忘后，来源摘要和支持证据进行脱敏；验证同时检查正文、事件载荷、索引、图关系、缓存和事实核对队列，客户端根据实际验证状态显示完成或待检查。

事实更新按主体、属性、项目与保存范围查找当前记录。用户明确纠正时生成新版本；新旧事实相冲突且缺少明确替换意图时进入事实核对队列，保存候选编号、版本快照及来源跨度。用户可以保留原值，或接受新值并生成版本。创建核对记录和提交更新时均在写事务内检查候选；接受新值时，记忆版本、来源关系、核对状态与提交审计共同提交，发生中断后沿暂存写入恢复。候选发生变化或另一项决定已经生效时，取消过期写入并要求重新核对。遗忘目标记忆会清理核对队列中引用的正文、主体、项目、来源和候选信息；遗忘来源事件也会关闭相应核对记录，防止被撤回的内容再次生效。

检索接口共享项目和会话条件。指定项目时可使用该项目与全局记忆，会话记忆还需匹配所属会话；这些条件先于候选数量限制执行，覆盖词法检索、向量候选、图检索、关联查询和批量上下文构建。管理查询可以省略项目字段查看跨项目内容，Agent 接入应传入当前项目目录。参数约定和示例见[接口文档](api.md)。

OpenHands 上下文快照同时绑定 namespace、项目、会话、Agent 与任务类型。检查点以只读事务核对所选记忆的当前版本、状态和作用域，并对所有适用偏好候选及其来源顺序生成签名。因此，新加入的覆盖偏好即使没有修改旧记录，也会使旧上下文失效。检查失败时停止当前任务并要求重新开始，新的上下文再读取当前记忆。此保护位于接入的 SDK 检查点，不抢占已经执行中的工具，也不负责清理模型内部状态。

语义检索使用单调时钟的绝对截止时间：候选召回、提供器锁等待、并发请求合并和重排共享剩余预算。SDK 子进程不再设置一秒的最低超时；预算耗尽或向量结果不完整时，整组回退到轻量检索，不将部分重排结果混作完整结果。持久化向量携带内容哈希、模型版本和任务令牌，后台回填提交时再次检查当前记录，避免遗忘或修改后过期任务复活旧向量。

## 5. OS 机制

| 机制 | 目的 | 证据 |
|---|---|---|
| mmap | OS 支持的段文件读取 | `AppendOnlyMemoryStore.scan()` |
| 追加式 + compact | 版本历史与不可逆清除 | `mmap_store.py`、测试 |
| namespace 隔离 | 多会话/多项目记忆、审计和敏感规则隔离 | `memctl --namespace`、`namespace-status`、`memguardd@.service` |
| systemd/cgroup | 资源限制和实例化 daemon | `memguardd.service`、`memguardd@.service`、`memctl status` |
| journald | 系统审计集成 | `JournaldLogger` |
| auditd | 敏感路径监控 | `auditd-rules`、安装脚本 |
| BPF LSM | 可选强制拦截和策略生成 | `native/bpf_lsm/`、`generate_bpf_lsm_policy.py` |
| UKUI | openKylin 桌面生态入口 | `native/ukui/`、`verify_ukui_plugins.sh` |
| OS 事件接入 | 接入 auditd/fanotify/eBPF 风格事件 | `ingest-os-event` |
| systemd Agent bridge | 以普通用户和资源限制运行 OpenHands 队列任务 | `memguard-agent@.service` |

后台向量维护由 daemon 的独立线程与独立 SQLite 连接承担，默认每 30 秒最多处理 8 项，单轮向量工作预算为 2 秒。调度读取本进程所在 cgroup 及祖先的内存配额，同时读取 cgroup 与系统的 PSI；内存占配额达到 85%，或内存、I/O、CPU 的 `some avg10` 分别达到 5%、10%、25% 时推迟维护，不把资源压力误记为向量任务失败。压力不可读时按有界模式运行。阈值是可解释的保守工程默认值，性能收益需在目标硬件上做对照测量。

启动参数为 `--maintenance-interval`、`--maintenance-budget` 与 `--maintenance-batch`；间隔为 0 或 `MEMGUARD_EMBEDDING_MAINTENANCE=0` 可关闭维护。没有向量提供器时不启动维护线程。维护状态进入 daemon 心跳，包含完成、延后、失败与已处理数量，不记录记忆正文。此策略参考 [Linux PSI](https://docs.kernel.org/accounting/psi.html) 与 [cgroup v2](https://docs.kernel.org/admin-guide/cgroup-v2.html) 的实际资源语义。

使用用户桌面的 Kylin AI SDK 时可显式启动 `systemctl --user enable --now memguardd-user.service`。该服务以当前用户运行，读取其 SDK socket，使用独立的私有记忆 API socket，配备 `MemoryHigh=384M`、`MemoryMax=512M` 和 `CPUQuota=50%`。安装包只提供单元，不自动启动或修改用户现有记忆。系统级 `memguardd.service` 与用户级服务分别管理各自目录；系统服务不会为了接通桌面 SDK 放宽 root 访问策略。

## 6. 评测摘要

当前评测覆盖：

- 类型与子类型识别准确率；
- Recall@5 与跨语言 Recall@5；
- 图谱实体 Recall@5；
- 敏感阻断 F1 与脱敏 F1；
- 遗忘候选精确率/召回率；
- 冲突解决正确率；
- 记忆层级流转；
- 负载 P50/P95/P99；
- CPU、tracemalloc、RSS、存储占用。
- 用户-Agent 交互的显式偏好、隐式习惯、角色污染负例、纠正反馈、工具轨迹、跨会话复用与精准遗忘。

生成命令：

```bash
python -m pytest -q
python -m memguard.eval.run_eval --latency-size 1000 --latency-queries 120 --output output/eval_result.json --markdown output/eval_report.md
```

## 7. 设计取舍与运行策略

工具输出先作为执行证据保存，其中出现“以后”“优先”或工具名称也不会直接形成用户偏好。这一来源边界由抽取器固定执行，工具输出不交给可选增强器重新解释为用户意愿。显式偏好来自用户交互，隐式工具经验则需要已完成任务、成功结果和跨会话的独立支持，始终与用户授权的偏好分开记录。因此，工具输出里的说明文字既不能覆盖工具偏好，也不会因包含同一工具名而混入只针对偏好的遗忘预览。

### 7.1 验证后的流程记忆与来源撤回

长期记忆中的操作经验采用结构化流程描述，保存目标、参数、步骤、风险约束、环境条件和完成检查。用户或 Agent 适配器提供流程规范与来源编号，服务读取当前工作区的实际文件验证条件；全部检查通过后，流程才成为可复用记忆。步骤作为建议提供给 Agent，不在记忆服务中执行。文件存在、包含和不包含指定内容是当前支持的三类检查，因此一次验证证明的是这些可观测条件，不会把工具退出码或模型自述等同于整个任务完成。

流程使用普通记忆的追加版本、敏感检测、隔离和持久向量链路。`memory_dependency` 保存流程当前版本与来源版本之间的 `derived_from` 关系，和实体、相似关系图分开管理。写入准备阶段及提交阶段都在 SQLite 写事务中检查来源版本、可信状态和作用范围。项目来源不能提升成全局经验，会话来源不能提升成长久经验；循环依赖、撤回来源或旧版本快照均拒绝写入。来源变化后，递归失效与源记录更新处于同一事务，检索和上下文立即排除过时派生记录，后续重新验证形成新的流程版本或记录。

撤回来源时，预览展示全部硬派生记录，并绑定相应版本。执行事务重新检查派生闭包，范围变化则要求重新预览；确认后的闭包统一进入原有可恢复遗忘链路。尚未提交的派生写入同步取消，正文、索引、依赖关系和流程反馈一起清理。相似主题的独立记录继续保留，避免通过关联图扩大删除授权。上下文装配保留整条流程的步骤、参数、约束和完成条件，窗口不足时整体跳过，不截掉风险约束。

追加正文后发生中断时，取消元数据写入还需要处理段文件中尚未提交的版本。`pending_segment_cleanup` 以记忆编号和版本编号登记清理任务，取消写入与登记处于同一 SQLite 事务。恢复过程按版本移除孤立正文，保留已经提交的历史；段文件重写或数据库检查点失败时保留任务，重开服务后继续执行。这样，删除成功不只意味着索引中查不到记录，还要求受管正文的恢复与清理链路完成。流程学习目前接受全局或匹配项目的来源；带 Agent、任务类型或独立会话偏好限制的来源在适用条件未接入流程协议前拒绝提炼，避免扩大来源授权。

`procedure_feedback` 只记录流程版本、会话、使用编号和实际检查的三态结果，不记录文件正文或参数。相同使用编号重复反馈不会增加计数，发生版本或来源变化时停止提交。成功率只基于 `pass` 与 `fail`，`unknown` 单独展示。这些数据用于观察流程在后续任务中的实际适用情况，真实 Agent 行动和完整任务收益仍由独立配对评测确认。

语义候选生成、SDK 调用与重排共用一个高精度单调时钟和绝对截止时间，不在降级阶段重新启动预算。超时或 SDK 不可用时保留有文本依据的轻量候选，丢弃迟到向量，不重复发起语义调用。Windows Python 3.11 的常规单调时钟精度可能超过毫秒级预算，因此这些阶段统一采用 `perf_counter`；该选择保持 Linux 与 Windows 的预算语义一致。

### 7.2 可选后端与运行边界

| 设计取舍 | 运行策略 |
|---|---|
| 默认抽取器保持离线可复现 | 采用可解释混合语义信号；需要更强泛化时通过 `MEMGUARD_EXTRACTOR_COMMAND` 显式接入本地 NER/LLM JSON 增强器 |
| Kylin embedding 不作为默认主路径 | Python/C++ 探针均已返回 768 维向量，`MEMGUARD_EMBEDDING_BACKEND=auto` 实际检索可返回 `vector_backend: "kylin_sdk"`；默认检索保持轻量 FTS/hash/graph，保证跨环境复现 |
| Kylin 向量数据库不作为默认存储路径 | 已有真实 C++ 搜索探针证据；默认元数据和索引仍由 SQLite/mmap 承担，便于离线评测 |
| BPF LSM 不是默认安全主路径 | auditd 已提供真实 OS 事件路径；BPF LSM 已验证安全测试文件强制拒绝，并支持 JSON 策略生成，不影响默认验证链路 |
| UKUI 可见性依赖目标环境安装 | Peony 右键菜单和 UKUI 控制中心入口均已完成 openKylin 桌面可见验证；bind mount 演示安装不等同于正式 `.deb` 包安装 |
| 本地小模型复杂命令能力有限 | 真实 OpenHands 会话已证明上下文注入、终端调用和事件回收；模型命令生成失败与记忆选择结果分开评估，不夸大为所有任务稳定完成 |
| 外部 Agent 可能保留交互副本 | MemGuardOS 精准遗忘清理其管理的事件、记忆、索引、图谱和段文件；OpenHands 会话、模型服务日志、shell history 和备份需调用外部系统删除机制 |
