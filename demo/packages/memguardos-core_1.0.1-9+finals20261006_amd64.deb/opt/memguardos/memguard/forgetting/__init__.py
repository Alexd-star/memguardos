"""Natural-language forgetting."""

