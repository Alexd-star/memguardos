"""Local MemGuardOS API."""
