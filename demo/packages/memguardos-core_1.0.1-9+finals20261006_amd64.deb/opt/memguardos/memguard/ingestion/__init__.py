"""Structured ingestion helpers."""

