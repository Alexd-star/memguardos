"""Memory extraction helpers."""

